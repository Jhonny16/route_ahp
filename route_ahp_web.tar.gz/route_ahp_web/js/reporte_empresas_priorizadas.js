$(document).ready(function () {

listado();
});

function listado() {
    var ruta = DIRECCION_WS + "reporte_empresas_priorizadas.php";
    var token = localStorage.getItem('token');

    $("#empresas_priorizadas").html("");

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: {},
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;


            if (datosJSON.estado == 200) {
                list_precios = resultado.datos;
                var html = "";
                html += '<table id="tbl_empresas_priroizadas" class="table table-bordered  small">';
                html += '<thead>';
                html += '<tr >';
                html += '<th style="text-align: center;background-color: #f3f3f3; ;color:#8c8c8c" rowspan="2">#</th>';
                html += '<th style="width: 15%;background-color: #f3f3f3; ;color:#8c8c8c" rowspan="2" align="MIDDLE">Nombre de la Empresa</th>';
                html += '<th colspan="4" style="text-align: center;background-color: #f3f3f3; color:#8c8c8c">Prioridad por criterios</th>';

                html += '<th style="background-color: #09bb8e; text-align: center;color:#8c8c8c">Prioridad general</th>';
                html += '<th colspan="4" style="text-align: center;background-color: #f3f3f3 ;color:#8c8c8c">Datos adicionnales</th>';

                html += '</tr>';

                html += '<tr style="background-color: #a2ffe8; height:25px;" >';

                html += '<th>Calidad servicio</th>';
                html += '<th>Precio</th>';
                html += '<th>Puntualidad</th>';
                html += '<th>Antiguedad vehicular</th>';
                html += '<th style="; text-align: center">Valor empresa</th>';
                html += '<th>Cédula autorización</th>';
                html += '<th>Tarjeta única circulación</th>';
                html += '<th>Credencial conductor</th>';
                html += '<th>Brevete conductor</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {
                    html += '<tr style="text-align: right">';
                    html += '<td style="text-align: center">' + (i + 1) + '</td>';
                    html += '<td style="text-align: left">' + item.nombre_completo + ' </td>';
                    if(item.calidad_servicio <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.calidad_servicio +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.calidad_servicio +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.calidad_servicio <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.calidad_servicio +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.calidad_servicio +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.calidad_servicio <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.calidad_servicio +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.calidad_servicio +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.calidad_servicio +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.calidad_servicio +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }

                    if(item.precio <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.precio +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.precio +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.precio <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.precio +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.precio +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.precio <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.precio +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.precio +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.precio +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.precio +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }
                    if(item.puntualidad <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.puntualidad +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.puntualidad +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.puntualidad <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.puntualidad +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.puntualidad +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.puntualidad <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.puntualidad +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.puntualidad +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.puntualidad +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.puntualidad +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }

                    if(item.antiguedad_vehicular <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.antiguedad_vehicular +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.antiguedad_vehicular +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.antiguedad_vehicular <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.antiguedad_vehicular +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.antiguedad_vehicular +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.antiguedad_vehicular <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.antiguedad_vehicular +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.antiguedad_vehicular +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.antiguedad_vehicular +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.antiguedad_vehicular +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }
                    // html += '<td>' + item.calidad_servicio + ' %</td>';
                    // html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.calidad_servicio +'%</b></span> ' +
                    //     '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.calidad_servicio +'%">' +
                    //     '</div></div></div></td>';
                    // html += '<td>' + item.precio + ' %</td>';
                    // html += '<td style="width: 9%"> <div class="progress-group"><span class="float-right"><b>310</b>/400</span> <div class="progress progress-sm"> <div class="progress-bar bg-danger" style="width: 75%"></div> </div> </div></td>';
                    // html += '<td style="width: 9%">' + item.puntualidad + ' %</td>';
                    // html += '<td style="width: 9%">' + item.antiguedad_vehicular + ' %</td>';
                    html += '<td style="background-color: #09bb8e; color: white"><strong>' + item.valor_empresa + ' %</strong></td>';
                    if(item.cedula_autorizacion == true){
                        html += '<td style="text-align: center"><i class="fa fa-check-circle text-blue" </i></td>';
                    }else{

                        html += '<td style="text-align: center"><i class="fa fa-times-circle text-orange"></i></td>';

                    }
                    // html += '<td>' + item.cedula_autorizacion + '</td>';
                    if(item.tarjeta_unica_circulacion <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.tarjeta_unica_circulacion +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.tarjeta_unica_circulacion +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.tarjeta_unica_circulacion <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.tarjeta_unica_circulacion +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.tarjeta_unica_circulacion +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.tarjeta_unica_circulacion <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.tarjeta_unica_circulacion +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.tarjeta_unica_circulacion +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.tarjeta_unica_circulacion +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.tarjeta_unica_circulacion +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }

                    if(item.credencial_conductor <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.credencial_conductor +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.credencial_conductor +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.credencial_conductor <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.credencial_conductor +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.credencial_conductor +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.credencial_conductor <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.credencial_conductor +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.credencial_conductor +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.credencial_conductor +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.credencial_conductor +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }

                    if(item.brevete_conductor <= 25){
                        html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.brevete_conductor +'%</b></span> ' +
                            '<div class="progress progress-sm"><div class="progress-bar bg-danger" style="width: '+ item.brevete_conductor +'%">' +
                            '</div></div></div></td>';
                    }else{
                        if(item.brevete_conductor <= 50){
                            html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.brevete_conductor +'%</b></span> ' +
                                '<div class="progress progress-sm"><div class="progress-bar bg-warning" style="width: '+ item.brevete_conductor +'%">' +
                                '</div></div></div></td>';
                        }else{
                            if(item.brevete_conductor <= 75){
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.brevete_conductor +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-success" style="width: '+ item.brevete_conductor +'%">' +
                                    '</div></div></div></td>';
                            }else{
                                html += '<td style="width: 9%"><div class="progress-group"><span class="float-right"><b>&nbsp;' + item.brevete_conductor +'%</b></span> ' +
                                    '<div class="progress progress-sm"><div class="progress-bar bg-primary" style="width: '+ item.brevete_conductor +'%">' +
                                    '</div></div></div></td>';
                            }
                        }
                    }
                    // html += '<td>' + item.tarjeta_unica_circulacion + ' %</td>';
                    // html += '<td>' + item.credencial_conductor + ' %</td>';
                    // html += '<td>' + item.brevete_conductor + ' %</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#empresas_priorizadas").html(html);
                $('#tbl_empresas_priroizadas').DataTable({  "aaSorting": [[6, "desc"]],});
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}

