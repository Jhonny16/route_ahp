var operation = null;
var empresa_id = 0;
var colegio_id = 0;
$(document).ready(function () {

    listado();
    combo_colegios();
    conductores_vehiculos();
});


$("#combo_param").change(function () {
    if ($("#combo_param").val() == 0) {
        $("#fecha_solicitud").attr('disabled', 'disabled');
    } else {
        $("#fecha_solicitud").removeAttr('disabled');
    }

});

var array_references = [];

function combo_colegios() {
    $("#combo_colegios_solicitud").empty();
    var ruta = DIRECCION_WS + "colegio_list.php";
    var token = localStorage.getItem('token');


    console.log(ruta);
    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify({"colegio_id": 0}),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Colegio --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {

                    html += '<option value="' + item.id + '" >Colegio: ' + item.nombre + '</option>';


                });
                $("#combo_colegios_solicitud").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}

function listado() {
    var ruta = DIRECCION_WS + "solicitudes_por_empresa_aceptadas.php";
    var token = localStorage.getItem('token');

    $("#solicitud_aceptada_list").html("");

    var parametro = $("#combo_param").val();
    var fechas = $("#fecha_solicitud").val();
    var fecha1 = fechas.substr(0, 10);
    var fecha2 = fechas.substr(13, 23);
    var colegio = $("#combo_colegios_solicitud").val();
    var turno = $("#combo_turno_solicitud").val();

    if (colegio == null) {
        colegio = 0;
    }


    var data = {
        'empresa_id': ide,
        'parametro': parametro,
        'fecha_inicio': fecha1,
        'fecha_fin': fecha2,
        'colegio_id': colegio,
        'turno': turno
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="solicitud_aceptada_list_table" class="table table-bordered table-striped text-sm">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; width:25%;">';
                html += '<th style="text-align: center">Sel</th>';
                html += '<th>Estado</th>';
                html += '<th>Número solicitud</th>';
                html += '<th>Apoderado</th>';
                html += '<th>Colegio</th>';
                html += '<th>Alumno</th>';
                html += '<th>Fecha Solicitud</th>';
                html += '<th>Fecha contrato</th>';
                html += '<th>Horario</th>';
                html += '<th>Turno</th>';
                html += '<th>Grado/Seccion</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {

                    html += '<tr style="background-color: #afffac; " >';


                    html += '<td><div class="icheck-primary d-inline">' +
                        '<input type="checkbox" id="checkboxPrimary'+item.referencia_id+'" onchange="onchange_solicitud(' + item.referencia_id + ')">' +
                        '<label for="checkboxPrimary'+item.referencia_id+'"></label> ' +
                        '</div></td>';
                    html += '<td>' + item.estado + '</td>';
                    html += '<td>' + item.solicitud + '</td>';
                    html += '<td>' + item.apoderado + '</td>';
                    html += '<td>' + item.colegio + '</td>';
                    html += '<td>' + item.alumno + '</td>';
                    html += '<td>' + item.fecha_solicitud + '</td>';
                    html += '<td>' + item.fecha_contrato + '</td>';
                    html += '<td>' + item.horario + '</td>';
                    html += '<td>' + item.turno + '</td>';
                    html += '<td>' + item.grado_seccion + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#solicitud_aceptada_list").html(html);
                $("#solicitud_aceptada_list_table").DataTable({
                    "paging": true,
                    "lengthChange": true,
                    "searching": true,
                    "ordering": true,
                    "info": true,
                    "autoWidth": true,
                    "sScrollX": "130%",
                    "sScrollXInner": "130%"
                });
                // $('#solicitud_list_table').DataTable({
                //     "aaSorting": [[0, "asc"]],
                //     "bScrollCollapse": true,
                //     "bPaginate": true,
                //     "sScrollX": "130%",
                //     "sScrollXInner": "100%",
                //
                // });
            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}


function conductores_vehiculos() {

    var ruta = DIRECCION_WS + "chofer_vehiculo_serv_list.php";

    var token = localStorage.getItem('token');

    $("#combo_chofer_vehiculo_serv").empty();


    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify({"empresa_id": ide}),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0" selected>-- Seleccione Chofer/Vehículo --</option>';

                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Chofer: ' + item.chofer + ' / Vehículo: ' + item.vehiculo + '</option>';

                });
                $("#combo_chofer_vehiculo_serv").append(html);

            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}

function onchange_solicitud(id) {
    array_references.push({'referencia_id': id});
}

function env_service() {
    if (array_references.length <= 2) {
        swal("Tome nota!", "Debe seleccionar al menos 3 solicitudes", "warning");
    } else {
        swal({
            title: 'Pregunta:',
            text: "Desea generar un servicio con las solicitudes seleccionadas?",
            type: 'info',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Aceptar!',
            cancelButtonText: 'Cancelar!'
        }).then(function (result) {
            if (result.value) {
                create_service(array_references);
            }

        })
    }


}

function create_service(array_referencia) {
    var ruta = DIRECCION_WS + "servicio_create.php";
    var token = localStorage.getItem('token');

    var jsonDetalle = JSON.stringify(array_referencia);


    var cv_id = $("#combo_chofer_vehiculo_serv").val();
    if(cv_id == 0){
        swal("Lo siento!", "Debe seleccionar el vehiculo y conductor para este servicio", "warning");
        return 0;
    }

    var data = {
        'detalle_referencia': jsonDetalle,
        'empresa_id': ide,
        'conductor_vehiculo_id': cv_id,
        'latitud': localStorage.getItem('latitud'),
        'longitud': localStorage.getItem('longitud'),
    };
    console.log(data);
    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                swal("Genial !", datosJSON.mensaje, "success");

            }else{
                swal("Error", datosJSON.mensaje, "error");

            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });

}

