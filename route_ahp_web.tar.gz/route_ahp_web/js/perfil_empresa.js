$(document).ready(function () {
    read_perfil();

});
function read_perfil(){
    var ruta = DIRECCION_WS + "persona_perfil.php";
    var token = localStorage.getItem('token');

    console.log(ruta);
    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify({'persona_id': localStorage.getItem('id')}),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var data = resultado.datos;

                $("#p_empresa_id").val(data.id);
                $("#documento_empresa_id").val(data.id);

                if(data.documento_identidad.length  == 8){
                    $("#p_dni").click();
                    $("#p_nacimiento").val(data.fecha_nacimiento);
                    if(data.sexo == 'M'){
                        $("#p_masculino").click();
                    }else{
                        $("#p_femenino").click();
                    }


                }else{
                    $("#p_ruc").click();
                }
                $("#p_documento").val(data.documento_identidad);
                $("#p_nombre").val(data.nombre_completo);
                $("#p_direccion").val(data.direccion);
                $("#p_celular").val(data.celular);



            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}
var sexo = 'M';
$("#p_masculino").change(function () {
    if (this.checked) {
        sexo = 'M';

    }
});
$("#p_femenino").change(function () {
    if (this.checked) {
       sexo = 'F';


    }
});


var sexo = 'M';
$("#p_ruc").change(function () {
    if (this.checked) {
        sexo = 'M';

    }
});
$("#p_dni").change(function () {
    if (this.checked) {
        sexo = 'F';


    }
});


var param = 1;
$("#radioPrimary1").change(function () {
    if (this.checked) {
        $("#contrasenia").removeAttr('disabled');
        param = 1;

    }
});
$("#radioPrimary2").change(function () {
    if (this.checked) {
        $("#contrasenia").attr('disabled','disabled');
        $("#contrasenia").val("");
        param = 0;


    }
});

function myFunction() {
    var x = document.getElementById("contrasenia");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}

function update_perfil(){
    var ruta = DIRECCION_WS + "persona_perfil_update.php";
    var token = localStorage.getItem('token');

    var fn = $("#p_nacimiento").val();
    if(fn==""){
        fn = null;
    }

    var data = {
        nombre_completo: $("#p_nombre").val(),
        documento_identidad: $("#p_documento").val(),
        celular: $("#p_celular").val(),
        direccion: $("#p_direccion").val(),
        fecha_nacimiento:  fn,
        sexo: sexo,
        persona_id: localStorage.getItem('id'),
        param : param,
        password: $("#contrasenia").val()

    };


    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            if (resultado.estado == 200) {
                swal({
                    title: 'Exito!',
                    text: resultado.mensaje,
                    type: 'info',
                    showCancelButton: false,
                    confirmButtonColor: '#00ACD6',
                    confirmButtonText: 'Aceptar!',
                }).then(function (result) {
                    if (result.value) {
                        window.location = "../vista/perfil_empresa.php";
                    }
                });
            } else {
                swal("Nota !", resultado.mensaje, "warning");

            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}

//
// var tipo='CER';
// $("#p_tipo_documento").val(tipo);
//
// $("#r_cer").change(function () {
//     if (this.checked) {
//         tipo = 'CER';
//         $("#p_tipo_documento").val(tipo);
//     }
// });
// $("#r_cre").change(function () {
//     if (this.checked) {
//         tipo = 'CRE';
//         $("#p_tipo_documento").val(tipo);
//
//
//     }
// });
// $("#r_aut").change(function () {
//     if (this.checked) {
//         tipo = 'AUT';
//         $("#p_tipo_documento").val(tipo);
//
//
//     }
// });

/*
function save_licence_certificado() {
    var ruta = DIRECCION_WS + "empresa_licenses_save.php";
    var token = localStorage.getItem('token');

    var formData = new FormData($("#form_certificados")[0]);
    console.log(formData);
    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: false,
        processData: false,
        cache: false,
        data: formData,
        success: function (resultado) {
            console.log(resultado);
            if (resultado.estado == 200) {
                limpiar_certificado();
                swal({
                    type: 'info',
                    title: 'Bien!',
                    text: resultado.mensaje,
                })
            } else {
                swal({
                    type: 'warning',
                    title: 'Nota!',
                    text: resultado.mensaje,
                })
                return 0;
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });

}

function limpiar_certificado(){
    $("#p_imagen").val("");
    $("#p_fecha").val("");
    $("#p_name_image").val("");
}

function search_documentos(){
    var ruta = DIRECCION_WS + "empresa_licencias_search.php";
    var token = localStorage.getItem('token');

    $("#tbl_images_licenses").empty();

    var data = {
        'empresa_id': localStorage.getItem('id'),
        'tipo': $("#p_tipo_documento").val()
    }
    console.log(data);
    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            if (resultado.estado == 200) {

                var html = '';
                $.each(resultado.datos, function (i, item) {
                    var route = DIRECCION_WS_LICENCE_COMPANY + '' + item.imagen;
                    html+='<tr>';
                    html+='<div class="col-sm-2">';
                    html+='<a href="'+ route +'" data-toggle="lightbox" data-title="'+ item.descripcion +'" data-gallery="gallery">' +
                        '<img src="'+ route +'" class="img-fluid mb-2" alt="'+ item.descripcion +'"></a>';
                    html+='</div>';
                    html+='<span>'+ item.descripcion +'</span>';

                    html+='</tr>';

                });
                $("#tbl_images_licenses").empty();



            } else {
                swal("Nota !", resultado.mensaje, "warning");

            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}*/
