var operation = null;
$(document).ready(function () {
  listado();
});


$("#doc_dni").change(function () {
  if (this.checked) {
    $("#documento_identidad").removeAttr('maxlength');
    $("#documento_identidad").attr('maxlength', '8');
    $("#div_sexo").removeAttr('style');
    $("#div_fn").removeAttr('style');
  }
});
$("#doc_ruc").change(function () {
  if (this.checked) {
    $("#documento_identidad").removeAttr('maxlength');
    $("#documento_identidad").attr('maxlength', '11');
    $("#div_sexo").attr('style','display:none');
    $("#div_fn").attr('style','display:none');
  }
});
// if ($('#doc_dni').prop('checked')) {
//   alert("hola");
// }

function listado() {
  var ruta = DIRECCION_WS + "empresas_list.php";
  var token = localStorage.getItem('token');

  $("#proveedor_lista").html("");
  $.ajax({
    type: "get",
    headers: {
      token: token
    },
    url: ruta,
    data: {},
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado == 200) {

        var html = "";
        $.each(datosJSON.datos, function (i, item) {

          html += '<div class="col-md-4">';
          html += '<div class="card card-widget widget-user-2">';
          html += '<div class="widget-user-header bg-gradient-info">';
          html += '<div class="widget-user-image">';
          html += '<img class="img-circle elevation-2" src="../images/building.png" alt="User Avatar">';
          html += '</div>';
          html += '<h3 class="widget-user-username">' + item.nombre_completo + '</h3>';
          html += '<h6 class="widget-user-desc">' + item.direccion + '</h6>';
          html += '</div>';
          html += '<div class="card-footer p-0">';
          html += '<ul class="nav flex-column">';
          html += '<li class="nav-item">';
          html += '<a class="nav-link">Documento: <span class="float-right badge bg-primary">' + item.documento_identidad + '</span></a>';
          html += '<a class="nav-link">Estado: <span class="float-right badge bg-primary">' + item.estado + '</span></a>';
          html += '</li>';
          html += '<li class="nav-item">';
          html += '<a href="../vista/chofer.php?empresa_id='+ item.id +'" class="nav-link">';
          html += ' Choferes <span class="float-right badge bg-info"><i class="fa fa-user"></i></span>';
          html += '</a>';
          html += '</li>';
          html += '<li class="nav-item">';
          html += '<a href="../vista/vehiculo.php?empresa_id='+ item.id +'" class="nav-link">';
          html += ' Vehículos <span class="float-right badge bg-info"><i class="fa fa-car"></i></span>';
          html += '</a>';
          html += '</li>';
          html += '<li class="nav-item">';
          html += '<a href="../vista/precio.php?empresa_id='+ item.id +'" class="nav-link">';
          html += ' Precios <span class="float-right badge bg-info"><i class="fa fa-money-bill"></i></span>';
          html += '</a>';
          html += '</li>';

          html += '<li class="nav-item">';
          html += '<a href="#" class="nav-link">';
          if (rol_id == 2){
            html += '<span class="float-right badge" > ' +
                '<button type="button" class="btn btn-block btn-warning btn-sm" data-toggle="modal" data-target="#mdl_empresa"' +
                'onclick="read('+ item.id +')"><i class="fa fa-edit"></i> Editar</button></span>';
          }

          html += '</a>';
          html += '</li>';
          html += '</ul>';
          html += '</div>';
          html += '</div>';
          html += '</div>';

        });


        $("#empresas_list").html(html);

      } else {
        swal({
          type: 'info',
          title: 'Nota!',
          text: datosJSON.mensaje,
        })
        return 0;
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });


}

function nueva_empresa() {
  operation = 'Nuevo';
  limpiar();
  $("#title_empresa").html("Registro");
}

var sexo='M';
$("#sexo_m").change(function () {
  if (this.checked) {
    sexo = 'M';
  }
});
$("#sexo_f").change(function () {
  if (this.checked) {
    sexo = 'F';

  }
});
function limpiar(){
  $("#documento_identidad").val("");
  $("#nombre_completo").val("");
  $("#direccion").val("");
  $("#celular").val("");
  $("#fecha_nacimiento").val("");
  $("#doc_ruc").click();
  $("#sexo_m").click();
}
function create() {

  var ruta = DIRECCION_WS + "empresa_create.php";
  var token = localStorage.getItem('token');

  var fn = $("#fecha_nacimiento").val();
  if(fn==""){
    fn = null;
  }

  var data = {
    nombre_completo: $("#nombre_completo").val(),
    documento_identidad: $("#documento_identidad").val(),
    celular: $("#celular").val(),
    direccion: $("#direccion").val(),
    estado: 'A',
    fn: fn,
    sexo: sexo,
    operation: operation
  };

  if(operation=='Editar'){
    data.id = $("#empresa_id").val()
  }
  console.log(data);

  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      if (resultado.estado == 200) {
        swal({
          title: 'Exito!',
          text: resultado.mensaje,
          type: 'info',
          showCancelButton: false,
          confirmButtonColor: '#00ACD6',
          confirmButtonText: 'Aceptar!',
        }).then(function (result) {
          if (result.value) {
            window.location = "../vista/empresa.php";
          }
        });
      } else {
        swal("Nota !", resultado.mensaje, "warning");

      }

    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

function read(id){
  limpiar();
  operation = 'Editar';

  var ruta = DIRECCION_WS + "empresa_read.php";
  var token = localStorage.getItem('token');
  var data = {'id': id};
  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      if (resultado.estado == 200) {
        $("#title_empresa").html("Editar");
        var data = resultado.datos;

        $("#empresa_id").val(data.id);

        if(data.documento_identidad.length  == 8){
          $("#doc_dni").click();
          $("#fecha_nacimiento").val(data.fecha_nacimiento);
          if(data.sexo == 'M'){
            $("#sexo_m").click();
          }else{
            $("#sexo_f").click();
          }


        }else{
          $("#doc_ruc").click();
        }
        $("#documento_identidad").val(data.documento_identidad);
        $("#nombre_completo").val(data.nombre_completo);
        $("#direccion").val(data.direccion);
        $("#celular").val(data.celular);


      } else {
        swal({
          type: 'info',
          title: 'Nota!',
          text: datosJSON.mensaje,
        })
        return 0;
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

