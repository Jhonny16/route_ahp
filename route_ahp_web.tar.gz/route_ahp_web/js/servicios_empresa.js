var operation = null;
var servicio_id = 0;
var cont = 0;
var array_destino = [];
var array_colegios = [];
var array_nodos = [];
$(document).ready(function () {

    listado();

});

function listado() {
    var ruta = DIRECCION_WS + "servicios_lista_por_empresa.php";
    var token = localStorage.getItem('token');

    $("#servicios_listado").html("");

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify({'empresa_id': ide}),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="servicios_empresa_list_table" class="table table-bordered table-striped text-sm">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; width:25%;">';
                html += '<th>Servicio</th>';
                html += '<th>N° alumnos</th>';
                html += '<th>Estado</th>';
                html += '<th style="text-align: center">Detalle</th>';
                html += '<th style="text-align: center">Posicion</th>';


                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {

                    html += '<tr style="background-color: #fff6f8; " >';


                    html += '<td>' + item.code + '</td>';
                    html += '<td style="text-align: center">  ' + item.numero_alumnos + '</td>';
                    html += '<td>' + item.state_service + '</td>';
                    html += '<td >';
                    html += '<span class="float-none badge" > ' +
                        '<button type="button" class="btn btn-block btn-warning btn-sm" data-toggle="modal" data-target="#moda_serv_detail"' +
                        'onclick="listado_detail('+ item.servicio_id +')"><i class="fa fa-list-ol"></i></button></span>';
                    html += '</td>';
                    html += '<td style="text-align: center">';
                    html += '<span class="float-none badge"> ' +
                        '<button type="button" class="btn btn-block btn-info btn-sm" ' +
                        'onclick="position('+ item.servicio_id +')"><i class="fa fa-marker"></i></button></span>';
                    html += '</td>';

                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#servicios_listado").html(html);
                $("#servicios_empresa_list_table").DataTable({
                    "paging": true,
                    "lengthChange": true,
                    "searching": true,
                    "ordering": true,
                    "info": true,
                    "autoWidth": true,
                });
                // $('#solicitud_list_table').DataTable({
                //     "aaSorting": [[0, "asc"]],
                //     "bScrollCollapse": true,
                //     "bPaginate": true,
                //     "sScrollX": "130%",
                //     "sScrollXInner": "100%",
                //
                // });
            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}




function listado_detail(id) {
    var ruta = DIRECCION_WS + "servicio_ruta_empresa.php";
    var token = localStorage.getItem('token');

    $("#div_servicio_detalle_list").html("");

    var data = {
        'servicio_id' : id
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="servicio_detalle_table" class="table table-bordered table-striped" style="font-size: 10px">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; height:25px;">';
                html += '<th style="text-align: center">#</th>';
                html += '<th>Colegio</th>';
                html += '<th>Alumno</th>';
                html += '<th>Fecha</th>';
                html += '<th>Observacion</th>';
                html += '<th>Hora llegada/salida</th>';
                html += '<th>Estado</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {
                    html += '<tr>';
                    html += '<td>' + (i + 1) + '</td>';
                    html += '<td>' + item.colegio + '</td>';
                    html += '<td>' + item.alumno + '</td>';
                    html += '<td>' + item.fecha + '</td>';
                    html += '<td>' + item.observacion + '</td>';
                    html += '<td>' + item.hora + '</td>';
                    html += '<td>' + item.estado_ruta + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#div_servicio_detalle_list").html(html);
                $('#servicio_detalle_table').DataTable();
            }


        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}

// var myVar = setInterval(servicio_posicion, 6000);


// carro.addListener('click', function () {
//     infowindow.open(mapita, carro);
// });

function servicio_posicion(){
    console.log("servicio_id: " + servicio_id);
    if (servicio_id > 0){
        var ruta = DIRECCION_WS + "servicio_ruta_posicion.php";
        var token = localStorage.getItem('token');

        var data = {'servicio_id': servicio_id};
        console.log(data);
        $.ajax({
            type: "post",
            headers: {
                token: token
            },
            url: ruta,
            contentType: "application/json",
            data: JSON.stringify(data),
            success: function (resultado) {
                console.log(resultado)
                if(resultado.estado == 200){
                    carro.setMap(null);
                    var position = {lat: parseFloat(resultado.datos.latitud) ,lng: parseFloat(resultado.datos.longitud) }
                    console.log(position);

                    var unidad = resultado.datos.vehiculo;
                    var chofer = resultado.datos.chofer;
                    var contentString = '<b>Unidad:</b>' + unidad + '<br>\n\
                        \<b>Chofer:</b>' + chofer + '<br>\n\
                          ';

                    carro = new google.maps.Marker({
                        position: position,
                        map: mapita,
                        //title: direccion,
                        icon: {
                            url: "../images/carrito.png",
                            scaledSize: new google.maps.Size(20, 20) // scaled size
                        },
                        //draggable: true
                    });

                    carro.setMap(mapita);

                    carro.addListener('click', function () {
                        infowindow.open(mapita, carro);
                    });

                    var infowindow = new google.maps.InfoWindow({
                        content: contentString
                    });


                }else{
                    console.log("No hay posiciones")
                    var position = {lat: parseFloat(localStorage.getItem('latitud')) ,lng: parseFloat(localStorage.getItem('latitud') ) }
                    empresa = new google.maps.Marker({
                        position: position,
                        map: mapita,
                        //title: direccion,
                        icon: {
                            url: "../images/empresa.png",
                            scaledSize: new google.maps.Size(20, 20) // scaled size
                        },
                        //draggable: true
                    });

                    empresa.setMap(mapita);



                }


            },
            error: function (error) {
                console.log(error);
                var datosJSON = $.parseJSON(error.responseText);
                swal("Error", datosJSON.mensaje, "error");
            }
        });
    }else{
        console.log("Intervalo activo sin servicio seleccionado. No hay problema.");
    }



}

function position(id){
    servicio_id = id;
    swal({
        title: 'Vista de ruta ... ',
        text: "Ver ubicacion actual del vehículo",
        type: 'info',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aceptar!',
        cancelButtonText: 'Cancelar!'
    }).then(function (result) {
        if (result.value) {
            if(servicio_id==0){

            }else{
                servicio_posicion(servicio_id);
                puntos_finales(id);
            }

        }

    })
}

function puntos_finales(id) {
    var ruta = DIRECCION_WS + "servicio_ruta_destino.php";
    var token = localStorage.getItem('token');


    var data = {
        'servicio_id' : id
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {
                var origen = {lat: parseFloat(localStorage.getItem('latitud')), lng: parseFloat(localStorage.getItem('longitud'))};
                array_colegios = datosJSON.datos;
                if (datosJSON.datos.length > 1){
                    $.each(datosJSON.datos, function (i, item) {
                        var destino =  {lat: parseFloat(item.latitud) , lng: parseFloat(item.longitud)};
                        calcular_distancia(origen,destino,item.id);
                    })
                }

            }


        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });

}

function puntos_nodos(id) {
    var ruta = DIRECCION_WS + "servicio_ruta_nodos.php";
    var token = localStorage.getItem('token');


    var data = {
        'servicio_id' : id
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {
                array_nodos = datosJSON.datos;
                if (datosJSON.datos.length > 1){
                     point_final();
                }

            }


        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });

}


function calcular_distancia(origen, destino,id){

    var directionsService = new google.maps.DirectionsService;
    var directionsDisplay = new google.maps.DirectionsRenderer({
        map: map_interno,
        panel: document.getElementById('lista_distancias')
    });

    directionsDisplay.addListener('directions_changed', function () {
        computeTotalDistance(directionsDisplay.getDirections(),id);
    });

    console.log('directionsDisplay');
    console.log(directionsDisplay);

    calculateAndDisplayRoute(directionsService, directionsDisplay, origen,destino);

}

var array_distance = []

function calculateAndDisplayRoute(directionsService, directionsDisplay, origen,destino) {
    console.log(origen);
    console.log(destino);
    directionsService.route({
        origin: origen,
        destination: destino,
        waypoints: [],
        travelMode: 'DRIVING',
        optimizeWaypoints: true,
        avoidTolls: true,
        provideRouteAlternatives: true

    }, function (response, status) {
        console.log(status);
        if (status === 'OK') {
            directionsDisplay.setDirections(response);
        } else {
            window.alert('Directions request failed due to ' + status);
        }
    });
}

function computeTotalDistance(result,id) {
    cont = cont +1 ;
    array_distance.push({'id': id, 'legs': result.routes[0].legs[0]});
    if (cont == array_colegios.length){
         puntos_nodos(servicio_id);
    }


}

function point_final(){
     console.log("array_distance");
     console.log(array_distance);
     console.log(array_colegios);
     var mayor = array_distance[0].legs.distance.value;
     var colegio_id =  array_distance[0].id;

    for(var i=0; i<array_distance.length; i++){
        if (array_distance[i].legs.distance.value > mayor){
            mayor = array_distance[i].legs.distance.value;
            colegio_id = array_distance[i].id;

        }
    }

    console.log(mayor);
    console.log(colegio_id);
    var lat ;
    var lng ;
    for(var i=0; i<array_colegios.length; i++){
        if(array_colegios[i].id == colegio_id){
            lat = array_colegios[i].latitud;
            lng = array_colegios[i].longitud;
        }
        else{
            array_nodos.push(array_colegios[i]);
        }
    }

    console.log("#resultados");
    console.log(lat);
    console.log(lng);
    console.log(array_nodos)
    calcular_distancia_2(array_nodos, {g);

}



function calcular_distancia_2(nodos, destino){

    var directionsService = new google.maps.DirectionsService;
    var directionsDisplay = new google.maps.DirectionsRenderer({
        map: map_direcciones,
        panel: document.getElementById('lista_distancias')
    });

    directionsDisplay.addListener('directions_changed', function () {
        computeTotalDistance_2(directionsDisplay.getDirections());
    });

    calculateAndDisplayRoute_2(directionsService, directionsDisplay, nodos, destino);

}

var data_all;
function calculateAndDisplayRoute_2(directionsService, directionsDisplay, nodos,destino) {
    console.log(nodos);
    console.log(destino);
    var array_nodos = []
    for (var i=0; i < nodos.length; i++){
        array_nodos.push({location:{lat: parseFloat(nodos[i].latitud), lng: parseFloat(nodos[i].longitud)} });
    }


    directionsService.route({
        origin: {lat: parseFloat(localStorage.getItem('latitud')), lng: parseFloat(localStorage.getItem('longitud'))},
        destination: destino,
        waypoints: array_nodos,
        travelMode: 'DRIVING',
        optimizeWaypoints: true,
        avoidTolls: true,
        provideRouteAlternatives: true

    }, function (response, status) {
        console.log(status);
        if (status === 'OK') {
            directionsDisplay.setDirections(response);
            data_all = response.routes[0].legs
        } else {
            window.alert('Directions request failed due to ' + status);
        }
    });
}

function computeTotalDistance_2(result) {
 console.log("result finaly");
 console.log(result);
}

var myVar = setInterval(myTimer, 10000);
var step = 0;
var cont = 0;
var ubicacion_carro = "";
function myTimer() {
    var data = [];
    data = data_all;
    console.log(data);
    if (data.length > 1) {
        console.log(cont);
        if (data.length === step) {
            alert("Ruta terminada");
            clearInterval(myVar);
        } else {
            if (data[step].steps.length === cont) {
                step++;
                cont = 0;
            }
            var postion_step = data[step].steps[cont].start_location;

            //console.log(postion_step);
            carro.setMap(null);

            carro = new google.maps.Marker({
                position: postion_step,
                map: map_direcciones,
                //title: direccion,
                icon: {
                    url: "../images/carrito.png",
                    scaledSize: new google.maps.Size(20, 20) // scaled size
                },
                //draggable: true
            });

            carro.setMap(map_direcciones);
            cont++;

        }


    }
}