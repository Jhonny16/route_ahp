var operation = null;

$(document).ready(function () {

    listado();

});

function listado() {
    var ruta = DIRECCION_WS + "servicios_lista_por_empresa.php";
    var token = localStorage.getItem('token');

    $("#servicios_listado").html("");

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify({'empresa_id': ide}),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="servicios_empresa_list_table" class="table table-bordered table-striped text-sm">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; width:25%;">';
                html += '<th style="text-align: center">Det.</th>';
                html += '<th>Servicio</th>';
                html += '<th>N° alumnos</th>';
                html += '<th>Estado</th>';

                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {

                    html += '<tr style="background-color: #fff6f8; " >';


                    html += '<td></td>';
                    html += '<td>' + item.code + '</td>';
                    html += '<td style="text-align: center">  ' + item.numero_alumnos + '</td>';
                    html += '<td>' + item.state_service + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#servicios_listado").html(html);
                $("#servicios_empresa_list_table").DataTable({
                    "paging": true,
                    "lengthChange": true,
                    "searching": true,
                    "ordering": true,
                    "info": true,
                    "autoWidth": true,
                });
                // $('#solicitud_list_table').DataTable({
                //     "aaSorting": [[0, "asc"]],
                //     "bScrollCollapse": true,
                //     "bPaginate": true,
                //     "sScrollX": "130%",
                //     "sScrollXInner": "100%",
                //
                // });
            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}