var operation = null;
var servicio_id = 0;
$(document).ready(function () {

    listado();

});

function listado() {
    var ruta = DIRECCION_WS + "servicios_lista_por_empresa.php";
    var token = localStorage.getItem('token');

    $("#servicios_listado").html("");

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify({'empresa_id': ide}),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="servicios_empresa_list_table" class="table table-bordered table-striped text-sm">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; width:25%;">';
                html += '<th>Servicio</th>';
                html += '<th>N° alumnos</th>';
                html += '<th>Estado</th>';
                html += '<th style="text-align: center">Detalle</th>';
                html += '<th style="text-align: center">Posicion</th>';


                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {

                    html += '<tr style="background-color: #fff6f8; " >';


                    html += '<td>' + item.code + '</td>';
                    html += '<td style="text-align: center">  ' + item.numero_alumnos + '</td>';
                    html += '<td>' + item.state_service + '</td>';
                    html += '<td >';
                    html += '<span class="float-none badge" > ' +
                        '<button type="button" class="btn btn-block btn-warning btn-sm" data-toggle="modal" data-target="#moda_serv_detail"' +
                        'onclick="listado_detail('+ item.servicio_id +')"><i class="fa fa-list-ol"></i></button></span>';
                    html += '</td>';
                    html += '<td style="text-align: center">';
                    html += '<span class="float-none badge"> ' +
                        '<button type="button" class="btn btn-block btn-info btn-sm" ' +
                        'onclick="position('+ item.servicio_id +')"><i class="fa fa-marker"></i></button></span>';
                    html += '</td>';

                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#servicios_listado").html(html);
                $("#servicios_empresa_list_table").DataTable({
                    "paging": true,
                    "lengthChange": true,
                    "searching": true,
                    "ordering": true,
                    "info": true,
                    "autoWidth": true,
                });
                // $('#solicitud_list_table').DataTable({
                //     "aaSorting": [[0, "asc"]],
                //     "bScrollCollapse": true,
                //     "bPaginate": true,
                //     "sScrollX": "130%",
                //     "sScrollXInner": "100%",
                //
                // });
            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}




function listado_detail(id) {
    var ruta = DIRECCION_WS + "servicio_ruta_empresa.php";
    var token = localStorage.getItem('token');

    $("#div_servicio_detalle_list").html("");

    var data = {
        'servicio_id' : id
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="servicio_detalle_table" class="table table-bordered table-striped" style="font-size: 10px">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; height:25px;">';
                html += '<th style="text-align: center">#</th>';
                html += '<th>Colegio</th>';
                html += '<th>Alumno</th>';
                html += '<th>Fecha</th>';
                html += '<th>Observacion</th>';
                html += '<th>Hora llegada/salida</th>';
                html += '<th>Estado</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {
                    html += '<tr>';
                    html += '<td>' + (i + 1) + '</td>';
                    html += '<td>' + item.colegio + '</td>';
                    html += '<td>' + item.alumno + '</td>';
                    html += '<td>' + item.fecha + '</td>';
                    html += '<td>' + item.observacion + '</td>';
                    html += '<td>' + item.hora + '</td>';
                    html += '<td>' + item.estado_ruta + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#div_servicio_detalle_list").html(html);
                $('#servicio_detalle_table').DataTable();
            }


        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}

var myVar = setInterval(servicio_posicion, 6000);


// carro.addListener('click', function () {
//     infowindow.open(mapita, carro);
// });

function servicio_posicion(){
    console.log("servicio_id: " + servicio_id);
    if (servicio_id > 0){
        var ruta = DIRECCION_WS + "servicio_ruta_posicion.php";
        var token = localStorage.getItem('token');

        var data = {'servicio_id': servicio_id};
        console.log(data);
        $.ajax({
            type: "post",
            headers: {
                token: token
            },
            url: ruta,
            contentType: "application/json",
            data: JSON.stringify(data),
            success: function (resultado) {
                console.log(resultado)
                if(resultado.estado == 200){
                    carro.setMap(null);
                    var position = {lat: parseFloat(resultado.datos.latitud) ,lng: parseFloat(resultado.datos.longitud) }
                    console.log(position);
                    carro = new google.maps.Marker({
                        position: position,
                        map: mapita,
                        //title: direccion,
                        icon: {
                            url: "../images/carrito.png",
                            scaledSize: new google.maps.Size(20, 20) // scaled size
                        },
                        //draggable: true
                    });

                    carro.setMap(mapita);

                }else{
                    console.log("No hay posiciones")
                    var position = {lat: parseFloat(localStorage.getItem('latitud')) ,lng: parseFloat(localStorage.getItem('latitud') ) }
                    empresa = new google.maps.Marker({
                        position: position,
                        map: mapita,
                        //title: direccion,
                        icon: {
                            url: "../images/empresa.png",
                            scaledSize: new google.maps.Size(20, 20) // scaled size
                        },
                        //draggable: true
                    });

                    empresa.setMap(mapita);

                }


            },
            error: function (error) {
                console.log(error);
                var datosJSON = $.parseJSON(error.responseText);
                swal("Error", datosJSON.mensaje, "error");
            }
        });
    }else{
        console.log("Intervalo activo sin servicio seleccionado. No hay problema.");
    }



}

function position(id){
    servicio_id = id;
    swal({
        title: 'Vista de ruta ... ',
        text: "Ver ubicacion actual del vehículo",
        type: 'info',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Aceptar!',
        cancelButtonText: 'Cancelar!'
    }).then(function (result) {
        if (result.value) {
            if(servicio_id==0){

            }else{
                servicio_posicion(servicio_id);
            }

        }

    })
}


