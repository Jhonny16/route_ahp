var operation = null;
$(document).ready(function () {
  combo_apoderados();
  listado();
});

function combo_apoderados() {
  $("#combo_apoderados").empty();
  var ruta = DIRECCION_WS + "apoderados_list.php";
  var token = localStorage.getItem('token');


  var data = {
    'apoderado_id': 0
  };

  console.log(data);

  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado === 200) {
        var html = "";
        html += '<option value="0">-- Ingrese dni o nombre del apoderado  --</option>';
        list_residuos = resultado.datos;
        $.each(datosJSON.datos, function (i, item) {
          html += '<option value="' + item.id + '" > ' + item.documento_identidad + ' - '+ item.nombre_completo +'</option>';


        });
        $("#combo_apoderados").append(html);
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

function listado() {
  var ruta = DIRECCION_WS + "apoderados_list.php";
  var token = localStorage.getItem('token');

  var apoderado_id = $("#combo_apoderados").val();
  if (apoderado_id == null) {
    apoderado_id = 0;
  }

  var data = {
    'apoderado_id': apoderado_id
  };

  console.log(data);

  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado == 200) {

        var html = "";
        $.each(datosJSON.datos, function (i, item) {


          html += '<div class="col-md-4">';
          html += '<div class="card card-widget widget-user-2">';
          html += '<div class="widget-user-header bg-gradient-info">';
          html += '<div class="widget-user-image">';
          html += '<img class="img-circle elevation-2" src="../images/papa.png" alt="User Avatar">';
          html += '</div>';
          html += '<h3 class="widget-user-username">' + item.nombre_completo + '</h3>';
          html += '<h6 class="widget-user-desc">' + item.direccion + '</h6>';
          html += '</div>';
          html += '<div class="card-footer p-0">';
          html += '<ul class="nav flex-column">';
          html += '<li class="nav-item">';
          html += '<a class="nav-link">Documento: <span class="float-right badge bg-primary">' + item.documento_identidad + '</span></a>';
          html += '<a class="nav-link">Estado: <span class="float-right badge bg-primary">' + item.estado + '</span></a>';
          html += '</li>';
          html += '<li class="nav-item">';
          html += '<a href="../vista/alumno.php?apoderado_id='+ item.id +'" class="nav-link">';
          html += ' Hijo(s) <span class="float-right badge bg-info"><i class="fa fa-user"></i></span>';
          html += '</a>';
          html += '</li>';

          html += '<li class="nav-item">';
          html += '<a href="#" class="nav-link">';
          html += '<span class="float-right badge"> ' +
            '</span>';
          html += '</a>';
          html += '</li>';
          html += '</ul>';
          html += '</div>';
          html += '</div>';
          html += '</div>';
        });


        $("#apoderado_list").html(html);

      } else {
        swal({
          type: 'info',
          title: 'Nota!',
          text: datosJSON.mensaje,
        })
        return 0;
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });


}

