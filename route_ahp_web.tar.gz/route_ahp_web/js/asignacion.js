var operation = null;
$(document).ready(function () {
    listado();
    combo_vehiculos();
    combo_choferes();

    //Aplicado a formulario modal
    combo_vehiculo();
    combo_chofer();
});

function combo_vehiculos() {
    $("#combo_vehiculo").empty();
    var ruta = DIRECCION_WS + "vehiculo_list.php";
    var token = localStorage.getItem('token');


    var data = {
        'empresa_id': 0,
        'vehiculo_id': 0
    };

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Vehiculo --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Placa: ' + item.placa + ' / Marca: ' + item.marca +'</option>';

                });
                $("#combo_vehiculo").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}
function combo_choferes() {
    $("#combo_chofer").empty();
    var ruta = DIRECCION_WS + "chofer_list.php";
    var token = localStorage.getItem('token');


    var data = {
        'empresa_id': 0,
        'chofer_id': 0
    };


    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Chofer   --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Chofer: ' + item.nombre_completo +'</option>';

                });
                $("#combo_chofer").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}


function listado() {
    var ruta = DIRECCION_WS + "chofer_vehiculo_asignacion_list.php";
    var token = localStorage.getItem('token');

    var vehiculo_id = $("#combo_vehiculo").val();
    var chofer_id = $("#combo_chofer").val();
    var fechas = $("#reservation").val();
    var fecha1 = fechas.substr(0, 10);
    var fecha2 = fechas.substr(13, 23);

    if(vehiculo_id == null){
        vehiculo_id = 0;
    }

    if(chofer_id == null){
        chofer_id = 0;
    }



    var data = {
        'vehiculo_id': vehiculo_id,
        'chofer_id': parseInt(chofer_id),
        'fecha_inicio': fecha1,
        'fecha_fin': fecha2
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="asignacion_list_table" class="table table-bordered table-striped small">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; height:25px;">';
                html += '<th style="text-align: center">#</th>';
                html += '<th>Conductor</th>';
                html += '<th>Vehículo</th>';
                html += '<th>Estado</th>';
                html += '<th>Fecha inicio</th>';
                html += '<th>Fecha término</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {
                    html += '<tr>';
                    html += '<td style="text-align: center"><a type="button"  data-toggle="modal" data-target="#mdl_asignacion" ' +
                        'title="Editar" onclick="read_asignacion(' + item.id + ')">' +
                        '<i class="fa fa-edit text-info"></i></a></td>';
                    html += '<td>' + item.chofer + '</td>';
                    html += '<td>' + item.vehiculo + '</td>';
                    html += '<td>' + item.estado + '</td>';
                    html += '<td>' + item.fecha_inicio +'</td>';
                    html += '<td>' + item.fecha_fin + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#asignacion_list").html(html);
                $('#asignacion_list_table').DataTable({
                    "aaSorting": [[0, "asc"]],
                    "bScrollCollapse": true,
                    "bPaginate": true,
                    "sScrollX": "170%",
                    "sScrollXInner": "100%",
                });
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}

function combo_vehiculo(){
    $("#combo_vehiculo_asign").empty();
    var ruta = DIRECCION_WS + "vehiculo_list.php";
    var token = localStorage.getItem('token');


    var data = {
        'empresa_id': localStorage.getItem('id'),
        'vehiculo_id': 0
    };

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Vehiculo --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Placa: ' + item.placa + ' / Marca: ' + item.marca +'</option>';

                });
                $("#combo_vehiculo_asign").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}

function combo_chofer(){
    $("#combo_conductor_asign").empty();
    var ruta = DIRECCION_WS + "chofer_list.php";
    var token = localStorage.getItem('token');


    var data = {
        'empresa_id': localStorage.getItem('id'),
        'chofer_id': 0
    };


    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Chofer   --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Chofer: ' + item.nombre_completo +'</option>';

                });
                $("#combo_conductor_asign").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}

function new_asignacion() {
    operation = 'Nuevo';
    $("#title_asignacion").html("Asignar");
    clear();
}


function clear(){
    $("#combo_conductor_asign").val('0');
    $("#combo_conductor_asign").select2().trigger('change');

    $("#combo_vehiculo_asign").val('0');
    $("#combo_vehiculo_asign").select2().trigger('change');
    $("#div_baja").removeAttr('style');
    $("#div_baja").attr('style','display:none');
    $("#activo").removeAttr('checked');

    $("#fecha_incial_asignacion").removeAttr('disabled');
}

var activo=1;
$("#r_yes").change(function () {
    if (this.checked) {
        activo = 1;
    }
});
$("#r_not").change(function () {
    if (this.checked) {
        activo = 0;

    }
});
function create_asignacion() {



    var ruta = DIRECCION_WS + "chofer_vehiculo_asignacion_create.php";
    var token = localStorage.getItem('token');

    console.log($("#activo").val());

    var data = {
        conductor_id: $("#combo_conductor_asign").val(),
        vehiculo_id: $("#combo_vehiculo_asign").val(),
        fecha_inicial: $("#fecha_incial_asignacion").val(),
        fecha_final: $("#fecha_final_asignacion").val(),
        activo: activo,
        operation: operation
    };

    if (operation == 'Editar') {
        data.id = $("#cv_id").val()
    }
    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            if (resultado.estado == 200) {
                swal({
                    title: 'Exito!',
                    text: resultado.mensaje,
                    type: 'info',
                    showCancelButton: false,
                    confirmButtonColor: '#00ACD6',
                    confirmButtonText: 'Aceptar!',
                }).then(function (result) {
                    if (result.value) {
                        window.location = "../vista/asignacion.php";
                    }
                });
            } else {
                swal("Nota !", resultado.mensaje, "warning");

            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}

function read_asignacion(id){
    $("#title_asignacion").html('Editar');
    operation = 'Editar';
    clear();

    var ruta = DIRECCION_WS + "chofer_vehiculo_asignacion_read.php";
    var token = localStorage.getItem('token');
    var data = {'id': id};
    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            if (resultado.estado == 200) {
                var data = resultado.datos;
                var ad = 14;
                $("#cv_id").val(data.id);
                $("#combo_conductor_asign").val(data.persona_id);
                $("#combo_conductor_asign").select2().trigger('change');
                $("#combo_vehiculo_asign").val(data.vehiculo_id);
                $("#combo_vehiculo_asign").select2().trigger('change');

                $("#fecha_incial_asignacion").val(data.fecha_inicio);
                $("#fecha_incial_asignacion").attr('disabled','disabled');
                $("#fecha_final_asignacion").val(data.fecha_fin)

                $("#div_baja").removeAttr('style');


                if (data.activo == true){
                    $("#r_yes").click();
                }else{
                    $("#r_not").click();

                }



            } else {
                swal({
                    type: 'info',
                    title: 'Nota!',
                    text: datosJSON.mensaje,
                })
                return 0;
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}