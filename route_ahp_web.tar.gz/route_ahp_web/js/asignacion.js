var operation = null;
$(document).ready(function () {
    listado();
    combo_vehiculos();
    combo_choferes();
});

function combo_vehiculos() {
    $("#combo_vehiculo").empty();
    var ruta = DIRECCION_WS + "vehiculo_list.php";
    var token = localStorage.getItem('token');


    var data = {
        'empresa_id': 0
    };


    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Vehiculo   --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Placa: ' + item.placa + ' / Marca: ' + item.marca +'</option>';

                });
                $("#combo_vehiculo").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}
function combo_choferes() {
    $("#combo_chofer").empty();
    var ruta = DIRECCION_WS + "chofer_list.php";
    var token = localStorage.getItem('token');


    var data = {
        'empresa_id': 0
    };


    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                var html = "";
                html += '<option value="0">-- Seleccione Chofer   --</option>';
                list_residuos = resultado.datos;
                $.each(datosJSON.datos, function (i, item) {
                    html += '<option value="' + item.id + '" >Chofer: ' + item.nombre_completo +'</option>';

                });
                $("#combo_chofer").append(html);
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });
}


function listado() {
    var ruta = DIRECCION_WS + "chofer_vehiculo_asignacion_list.php";
    var token = localStorage.getItem('token');

    var vehiculo_id = $("#combo_vehiculo").val();
    var chofer_id = $("#combo_chofer").val();
    var fechas = $("#reservation").val();
    var fecha1 = fechas.substr(0, 10);
    var fecha2 = fechas.substr(13, 23);

    if(vehiculo_id == null){
        vehiculo_id = 0;
    }

    if(chofer_id == null){
        chofer_id = 0;
    }



    var data = {
        'vehiculo_id': vehiculo_id,
        'chofer_id': chofer_id,
        'fecha_inicio': fecha1,
        'fecha_fin': fecha2
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="asignacion_list_table" class="table table-bordered table-striped">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; height:25px;">';
                html += '<th style="text-align: center">#</th>';
                html += '<th>Conductor</th>';
                html += '<th>Vehículo</th>';
                html += '<th>Fecha inicio</th>';
                html += '<th>Fecha término</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {
                    html += '<tr>';
                    html += '<td>' + item.id + '</td>';
                    html += '<td>' + item.chofer + '</td>';
                    html += '<td>' + item.vehiculo + '</td>';
                    html += '<td>' + item.fecha_inicio +'</td>';
                    html += '<td>' + item.fecha_fin + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#asignacion_list").html(html);
                $('#asignacion_list_table').DataTable({
                    "aaSorting": [[0, "asc"]],
                    "bScrollCollapse": true,
                    "bPaginate": true,
                    "sScrollX": "170%",
                    "sScrollXInner": "100%",
                });
            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}

