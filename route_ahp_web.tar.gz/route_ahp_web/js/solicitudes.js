var operation = null;
var empresa_id = 0;
var colegio_id = 0;
$(document).ready(function () {

    listado();

});

$("#combo_parametro").change(function () {
    if ($("#combo_parametro").val() == 0) {
        $("#fechas_solicitud").attr('disabled', 'disabled');
    } else {
        $("#fechas_solicitud").removeAttr('disabled');
    }

});

function listado() {
    var ruta = DIRECCION_WS + "solicitudes_por_empresa.php";
    var token = localStorage.getItem('token');

    $("#solicitud_list").html("");

    var parametro = $("#combo_parametro").val();
    var fechas = $("#fechas_solicitud").val();
    var fecha1 = fechas.substr(0, 10);
    var fecha2 = fechas.substr(13, 23);

    var data = {
        'empresa_id': ide,
        'parametro': parametro,
        'fecha_inicio': fecha1,
        'fecha_fin': fecha2
    };

    console.log(data);

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;

            if (datosJSON.estado == 200) {

                var html = "";
                html += '<table id="solicitud_list_table" class="table table-bordered table-striped text-sm">';
                html += '<thead>';
                html += '<tr style="background-color: #17a2b8; width:25%;">';
                html += '<th style="text-align: center">Sel</th>';
                html += '<th>Estado</th>';
                html += '<th>Número solicitud</th>';
                html += '<th>Apoderado</th>';
                html += '<th>Colegio</th>';
                html += '<th>Alumno</th>';
                html += '<th>F.solicitud</th>';
                html += '<th>F.inicio</th>';
                html += '<th>F.fin</th>';
                html += '<th>Hora entrada</th>';
                html += '<th>Hora salida</th>';
                html += '<th>Turno</th>';
                html += '<th>Grado/Seccion</th>';
                html += '</tr>';
                html += '</thead>';
                html += '<tbody>';
                $.each(datosJSON.datos, function (i, item) {
                    if (item.estado == 'Nuevo') {
                        html += '<tr style="background-color: #c9feed;color: #0f6674" >';
                    } else {
                        html += '<tr style="background-color: #fef7c9;color: #5f3f3f " >';
                    }

                    html += '<td><div class="icheck-primary d-inline">\n' +
                        '                        <input type="radio" name="r2" id="radioPrimary1" onclick="onchange_state(' + item.referencia_id + ')">\n' +
                        '                        <label for="radioPrimary1">\n' +
                        '                        </label>\n' +
                        '                      </div></td>';
                    html += '<td>' + item.estado + '</td>';
                    html += '<td>' + item.solicitud + '</td>';
                    html += '<td>' + item.apoderado + '</td>';
                    html += '<td>' + item.colegio + '</td>';
                    html += '<td>' + item.alumno + '</td>';
                    html += '<td>' + item.fecha_solicitud + '</td>';
                    html += '<td>' + item.fecha_inicio + '</td>';
                    html += '<td>' + item.fecha_fin + '</td>';
                    html += '<td>' + item.hora_entrada + '</td>';
                    html += '<td>' + item.hora_salida + '</td>';
                    html += '<td>' + item.turno + '</td>';
                    html += '<td>' + item.grado_seccion + '</td>';
                    html += '</tr>';
                });
                html += '</tbody>';
                html += '</table>';

                $("#solicitud_list").html(html);
                $("#solicitud_list_table").DataTable({
                    "paging": true,
                    "lengthChange": true,
                    "searching": true,
                    "ordering": true,
                    "info": true,
                    "autoWidth": true,
                    "sScrollX": "130%",
                    "sScrollXInner": "130%"
                });
                // $('#solicitud_list_table').DataTable({
                //     "aaSorting": [[0, "asc"]],
                //     "bScrollCollapse": true,
                //     "bPaginate": true,
                //     "sScrollX": "130%",
                //     "sScrollXInner": "100%",
                //
                // });
            }

        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });


}

var referencia_id = 0

function onchange_state(id) {
    referencia_id = id;
}

function env_state() {
    if (referencia_id == 0) {
        swal("Tome nota!", "Debe seleccionar una solicitud", "warning");
    } else {
        swal({
            title: 'Pregunta:',
            text: "Desea aceptar esta solicitud?",
            type: 'info',
            showCancelButton: true,
            confirmButtonColor: '#0f6674',
            cancelButtonColor: '#dd3500',
            confirmButtonText: 'Aceptar!',
            cancelButtonText: 'Cancelar!'
        }).then(function (result) {
            if (result.value) {
                acpetar_solicitud(referencia_id)
            }

        })
    }


}

function acpetar_solicitud(reference_id) {
    var ruta = DIRECCION_WS + "solicitud_state.php";
    var token = localStorage.getItem('token');

    var data = {'referencia_id': reference_id};

    $.ajax({
        type: "post",
        headers: {
            token: token
        },
        url: ruta,
        contentType: "application/json",
        data: JSON.stringify(data),
        success: function (resultado) {
            console.log(resultado);
            var datosJSON = resultado;
            if (datosJSON.estado === 200) {
                swal({
                    title: 'Pregunta:',
                    text: datosJSON.mensaje,
                    type: 'info',
                    confirmButtonColor: '#0f6674',
                    confirmButtonText: 'Aceptar :)',
                }).then(function (result) {
                    if (result.value) {
                        window.location = "../vista/solicitudes_aceptadas.php";
                    }

                })

            }
        },
        error: function (error) {
            console.log(error);
            var datosJSON = $.parseJSON(error.responseText);
            swal("Error", datosJSON.mensaje, "error");
        }
    });

}