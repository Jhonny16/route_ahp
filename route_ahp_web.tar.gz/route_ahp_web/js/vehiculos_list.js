var operation = null;
var empresa_id = 0;
$(document).ready(function () {
  if(rol_id == 2){
    empresa_id = ide;
  }else{
    empresa_id = 0;
  }

  vehiculos();
  empresas();

  getUrlVars();


});

function empresas(){
  $("#combo_empresas_veh").empty();
  var ruta = DIRECCION_WS + "empresas_list.php";
  var token = localStorage.getItem('token');


  console.log(ruta);
  $.ajax({
    type: "get",
    headers: {
      token: token
    },
    url: ruta,
    data: {},
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado === 200) {
        var html = "";
        html += '<option value="0">-- Seleccione Empresa --</option>';
        list_residuos = resultado.datos;
        $.each(datosJSON.datos, function (i, item) {
          if(empresa_id == item.id){
            html += '<option value="'+ item.id +'" selected>Empresa: ' + item.nombre_completo +'</option>';
          }
          else{
            html += '<option value="'+ item.id +'" >Empresa: ' + item.nombre_completo +'</option>';

          }

        });
        $("#combo_empresas_veh").append(html);
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

function vehiculos() {
  $("#combo_vehiculo").empty();
  var ruta = DIRECCION_WS + "vehiculo_list.php";
  var token = localStorage.getItem('token');


  console.log(ruta);
  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify({'empresa_id' : localStorage.getItem('id'), 'vehiculo_id': 0 }),
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado === 200) {
        var html = "";
        html += '<option value="'+ 0 +'">-- Seleccione Vehículo --</option>';
        $.each(datosJSON.datos, function (i, item) {
          html += '<option value="' + item.id + '" >Marca: ' + item.marca + ' / Placa: '+ item.placa +'</option>';
        });
        $("#combo_vehiculo").append(html);

      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

function getUrlVars() {
  var vars = {};
  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
    vars[key] = value;
  });
  console.log(vars);
  console.log(vars.empresa_id);
  if(empresa_id>1){
    empresa_id = empresa_id
  }else{
    empresa_id = vars.empresa_id;

  }

  if (empresa_id > 1){
    listado();
  }
  else{
    empresa_id = 0;
    listado();
  }
  //return vars;
}

function buscar() {
  empresa_id = $("#combo_empresas_veh").val();
  if(empresa_id == null){
    empresa_id = 0;
  }
  listado();

}


function listado() {
  var ruta = DIRECCION_WS + "vehiculo_list.php";
  var token = localStorage.getItem('token');

  $("#vehiculo_list").html("");

  vehiculo_id = $("#combo_vehiculo").val();
  if(vehiculo_id == null){
    vehiculo_id = 0;
  }

  var data = {
    'empresa_id': empresa_id,
    'vehiculo_id': vehiculo_id
  };

  console.log(data);

  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado == 200) {

        var html = "";
        $.each(datosJSON.datos, function (i, item) {

          html += '<div class="col-md-3">';
          html += '<div class="card card-widget widget-user-2">';
          html += '<div class="widget-user-header bg-gradient-light">';
          html += '<div class="widget-user-image">';
          html += '<img class="img-circle elevation-2" src="../images/vehiculo.png" alt="User Avatar">';
          html += '</div>';
          html += '<h3 class="widget-user-username">' + item.placa + '</h3>';
          html += '</div>';
          html += '<div class="card-footer p-0">';
          html += '<ul class="nav flex-column">';
          html += '<li class="nav-item">';
          html += '<a class="nav-link">Marca: <span class="float-right badge bg-secondary">' + item.marca  + '</span></a>';
          html += '<a class="nav-link">Color: <span class="float-right badge bg-secondary">' + item.color + '</span></a>';
          html += '<a class="nav-link">Empresa: <span class="float-right badge bg-secondary">' + item.empresa + '</span></a>';
          html += '</li>';
          html += '<li class="nav-item">';
          html += '<a href="#" class="nav-link">';
          if (rol_id == 2) {
            html += '<span class="float-right badge"> ' +
                '<button type="button" class="btn btn-block btn-default btn-sm" data-toggle="modal" data-target="#mdl_vehiculo"' +
                'onclick="read(' + item.id + ')"><i class="fa fa-edit"></i> Editar</button></span>';
          }
          html += '</a>';
          html += '</li>';
          html += '</ul>';
          html += '</div>';
          html += '</div>';
          html += '</div>';

        });


        $("#vehiculo_list").html(html);

      }

    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });


}


function new_vehiculo() {
  operation = 'Nuevo';
  limpiar();
  $("#title_vehiculo").html("Registro");
}

function limpiar(){
  $("#documento_identidad").val("");
  $("#nombre_completo").val("");
  $("#direccion").val("");
  $("#celular").val("");
  $("#fecha_nacimiento").val("");
  $("#doc_ruc").click();
  $("#sexo_m").click();
}

var estado=true;
$("#activo").change(function () {
  if (this.checked) {
    estado = true;
  }
});
$("#inactivo").change(function () {
  if (this.checked) {
    estado = false;

  }
});
function create() {

  var ruta = DIRECCION_WS + "vehiculo_create.php";
  var token = localStorage.getItem('token');

  var data = {
    placa: $("#placa").val(),
    marca: $("#marca").val(),
    color: $("#color").val(),
    empresa_id: localStorage.getItem('id'),
    estado: estado,
    operation: operation
  };

  if(operation=='Editar'){
    data.id = $("#vehiculo_id").val()
  }
  console.log(data);

  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      if (resultado.estado == 200) {
        swal({
          title: 'Exito!',
          text: resultado.mensaje,
          type: 'info',
          showCancelButton: false,
          confirmButtonColor: '#00ACD6',
          confirmButtonText: 'Aceptar!',
        }).then(function (result) {
          if (result.value) {
            window.location = "../vista/vehiculo.php";
          }
        });
      } else {
        swal("Nota !", resultado.mensaje, "warning");

      }

    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

function read(id){
  limpiar();
  operation = 'Editar';

  var ruta = DIRECCION_WS + "vehiculo_read.php";
  var token = localStorage.getItem('token');
  var data = {'id': id};
  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      if (resultado.estado == 200) {
        $("#title_vehiculo").html("Editar");
        var data = resultado.datos;

        $("#vehiculo_id").val(data.id);


        $("#placa").val(data.placa);
        $("#marca").val(data.marca);
        $("#color").val(data.color);
        if(data.activo == true){
          $("#activo").click();
        }else{
          $("#inactivo").click();
        }


      } else {
        swal({
          type: 'info',
          title: 'Nota!',
          text: datosJSON.mensaje,
        })
        return 0;
      }
    },
    error: function (error) {
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}