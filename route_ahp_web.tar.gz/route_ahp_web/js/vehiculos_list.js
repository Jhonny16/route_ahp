var operation = null;
var empresa_id = 0;
$(document).ready(function () {
  empresas();
  listado();
  getUrlVars();
});

function empresas(){
  $("#combo_empresas_veh").empty();
  var ruta = DIRECCION_WS + "empresas_list.php";
  var token = localStorage.getItem('token');


  console.log(ruta);
  $.ajax({
    type: "get",
    headers: {
      token: token
    },
    url: ruta,
    data: {},
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado === 200) {
        var html = "";
        html += '<option value="0">-- Seleccione Empresa --</option>';
        list_residuos = resultado.datos;
        $.each(datosJSON.datos, function (i, item) {
          if(empresa_id > 0){
            html += '<option value="'+ item.id +'" selected>Empresa: ' + item.nombre_completo +'</option>';
          }
          else{
            html += '<option value="'+ item.id +'" >Empresa: ' + item.nombre_completo +'</option>';

          }

        });
        $("#combo_empresas_veh").append(html);
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });
}

function getUrlVars() {
  var vars = {};
  var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
    vars[key] = value;
  });
  console.log(vars);
  console.log(vars.empresa_id);
  empresa_id = vars.empresa_id;
  //return vars;
}


function listado() {
  var ruta = DIRECCION_WS + "vehiculo_list.php";
  var token = localStorage.getItem('token');

  $("#vehiculo_list").html("");

  empresa_id = $("#combo_empresas_veh").val();
  if(empresa_id == null){
    empresa_id = 0;
  }

  var data = {
    'empresa_id': empresa_id
  };

  console.log(data);

  $.ajax({
    type: "post",
    headers: {
      token: token
    },
    url: ruta,
    contentType: "application/json",
    data: JSON.stringify(data),
    success: function (resultado) {
      console.log(resultado);
      var datosJSON = resultado;
      if (datosJSON.estado == 200) {

        var html = "";
        $.each(datosJSON.datos, function (i, item) {

          html += '<div class="col-md-3">';
          html += '<div class="card card-widget widget-user-2">';
          html += '<div class="widget-user-header bg-gradient-light">';
          html += '<div class="widget-user-image">';
          html += '<img class="img-circle elevation-2" src="../images/vehiculo.png" alt="User Avatar">';
          html += '</div>';
          html += '<h3 class="widget-user-username">' + item.placa + '</h3>';
          html += '</div>';
          html += '<div class="card-footer p-0">';
          html += '<ul class="nav flex-column">';
          html += '<li class="nav-item">';
          html += '<a class="nav-link">Marca: <span class="float-right badge bg-secondary">' + item.marca  + '</span></a>';
          html += '<a class="nav-link">Color: <span class="float-right badge bg-secondary">' + item.color + '</span></a>';
          html += '<a class="nav-link">Empresa: <span class="float-right badge bg-secondary">' + item.empresa + '</span></a>';
          html += '</li>';
          html += '<li class="nav-item">';
          html += '<a href="#" class="nav-link">';
          html += '<span class="float-right badge"> ' +
            '<button type="button" class="btn btn-block btn-default btn-sm" data-toggle="modal" data-target="#mdl_empresa"' +
            'onclick="read('+ item.id +')"><i class="fa fa-edit"></i> Editar</button></span>';
          html += '</a>';
          html += '</li>';
          html += '</ul>';
          html += '</div>';
          html += '</div>';
          html += '</div>';

        });


        $("#vehiculo_list").html(html);

      } else {
        swal({
          type: 'info',
          title: 'Nota!',
          text: datosJSON.mensaje,
        })
        return 0;
      }
    },
    error: function (error) {
      console.log(error);
      var datosJSON = $.parseJSON(error.responseText);
      swal("Error", datosJSON.mensaje, "error");
    }
  });


}
