<div class="modal fade" id="mdl_colegio">
    <div class="modal-dialog">
        <div class="modal-content bg-info">
            <div class="modal-header">
                <h4 class="modal-title" id="title_colegio"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <form role="form">
                            <input type="text" style="display: none;" id="colegio_id" >

                            <div class="card-body">

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Número</label>
                                    <input type="text" maxlength="6" class="form-control" id="numero" placeholder="Ingrese número">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Nombre</label>
                                    <input type="text" class="form-control" id="nombre" onkeypress="return sololetras(event);"
                                           placeholder="Ingrese nombre">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Dirección</label>
                                    <input type="text" class="form-control" id="direccion"
                                           placeholder="Ingrese direccion">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Director nombre</label>
                                    <input type="text" class="form-control" id="director" onkeypress="return sololetras(event);"
                                           placeholder="Ingrese director">
                                </div>
<!--                                <div class="form-group">-->
<!--                                    <label for="exampleInputEmail1">Precio S/.</label>-->
<!--                                    <input type="number" min="0" max="500" class="form-control" id="precio" onkeypress="return solonumeros(event);"-->
<!--                                           placeholder="Ingrese precio">-->
<!--                                </div>-->


                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-outline-light" onclick="create()">Guardar</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
