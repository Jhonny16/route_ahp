<html>
<head>
    <?php include_once 'ext_estilos.php'; ?>
</head>
<body class="hold-transition sidebar-mini text-sm">
<div class="wrapper">
    <?php include_once 'est_cabecera.php'; ?>
    <?php include_once 'est_menu.php'; ?>
    <div class="content-wrapper" style="background-color: white">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">

                    <div class="col-sm-8"></div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Solicitud(es)</a></li>
                            <li class="breadcrumb-item active">Aceptadas</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="card card-default">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-sm-2">
                                <div class="form-group text-sm">
                                    <select class="form-control select2bs4" style="width: 100%;" id="combo_parametro">
                                        <option value="0" selected>Todas las fechas</option>
                                        <option value="1">Rango de fechas</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group text-sm">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                      <span class="input-group-text">
                                        <i class="far fa-calendar-alt"></i>
                                      </span>
                                        </div>
                                        <input type="text" class="form-control float-right small" id="fecha_contrato"
                                               disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group text-sm">
                                    <select class="form-control select2bs4" style="width: 100%;"
                                            id="combo_colegios_solicitud">
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group text-sm">
                                    <select class="form-control select2bs4" style="width: 100%;"
                                            id="combo_turno_solicitud">
                                        <option value="0" >-- Seleccione turno --</option>
                                        <option value="Mañana" >Mañana</option>
                                        <option value="Tarde">Tarde</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2 pull-left">
                                <button type="button" class="btn btn-warning" onclick="listado()"><i
                                            class="fas fa-search"></i> Buscar
                                </button>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="card card-default">
                    <div class="card-header">
                        <h3 class="card-title">Solicitud(es) Aceptadas </h3>
                        <div class="card-tools">
                            <button type="button"  class="btn btn-success" data-toggle="modal" data-target="#mdl_cv_serv"
                                   ><i class="fas fa-"></i>
                                Crear Servicio
                            </button>
                        </div>
                    </div>
                    <div class="card-body" id="solicitud_aceptada_list">

                    </div>
                </div>
        </section>
        <?php include_once 'modal_conductor_vehiculo_serv.php'; ?>

    </div>
    <?php include_once 'est_pie.php'; ?>
</div>

<?php include_once 'ext_scripts.php'; ?>
<script src="../js/login.js"></script>
<script src="../js/validacion.js"></script>
<script src="../js/validate_login.js"></script>
<script src="../js/solicitudes_aceptadas.js"></script>

</body>
</html>
