<?php
//require_once '../util/funciones/definiciones.php';
?>
<html>
<head>
  <?php include_once 'ext_estilos.php'; ?>
</head>
<body class="hold-transition sidebar-mini text-sm">
<div class="wrapper">
  <?php include_once 'est_cabecera.php'; ?>
  <?php include_once 'est_menu.php'; ?>
  <?php include_once 'est_contenido.php'; ?>
  <?php include_once 'est_pie.php'; ?>

</div>
<?php include_once 'ext_scripts.php'; ?>
</body>
</html>
