<html>
<head>
  <?php include_once 'ext_estilos.php'; ?>
</head>
<body class="hold-transition sidebar-mini text-sm">
<div class="wrapper">
  <?php include_once 'est_cabecera.php'; ?>
  <?php include_once 'est_menu.php'; ?>
  <div class="content-wrapper" style="background-color: white">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Empresas - Servicio Movilidad Escolar</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Empresas</a></li>
              <li class="breadcrumb-item active">Listado</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="card card-default">
          <div class="card-header">
            <h3 class="card-title">Lista Empresas </h3>
            <div class="card-tools">
              <button type="button" id="create_empresa" style="display: none" class="btn btn-info" data-toggle="modal" data-target="#mdl_empresa" onclick="nueva_empresa()"><i class="fas fa-save"></i>
                Nuevo
              </button>
            </div>
          </div>
          <div class="card-body">
            <div class="row" id="empresas_list">
            </div>
          </div>
      </div>
    </section>
    <?php include_once 'mdl_empresa.php'; ?>

  </div>
  <?php include_once 'est_pie.php'; ?>
</div>

  <?php include_once 'ext_scripts.php'; ?>
  <script src="../js/login.js"></script>
  <script src="../js/validacion.js"></script>
  <script src="../js/validate_login.js"></script>
  <script src="../js/empresas_list.js"></script>

</body>
</html>
