<div class="modal fade" id="mdl_empresa">
  <div class="modal-dialog">
    <div class="modal-content bg-info">
      <div class="modal-header">
        <h4 class="modal-title" id="title_empresa"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-xs-12 col-md-12">
              <form role="form">
                <input type="text" style="display: none;" id="empresa_id" >

                <div class="card-body">
                  <div class="form-group clearfix">
                    <div class="icheck-success d-inline">
                      <input type="radio" name="doc_identidad" checked id="doc_ruc">
                      <label for="doc_ruc">RUC
                      </label>
                    </div>
                    <div class="icheck-success d-inline">
                      <input type="radio" name="doc_identidad" id="doc_dni">
                      <label for="doc_dni">DNI
                      </label>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Documento Ruc o DNI</label>
                    <input type="text" class="form-control" id="documento_identidad" placeholder="Ingrese RUC o DNI">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nombre completo o razon social</label>
                    <input type="text" class="form-control" id="nombre_completo" onkeypress="return sololetras(event);"
                           placeholder="Ingrese nombre completo o razon social">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Dirección</label>
                    <input type="text" class="form-control" id="direccion" placeholder="Ingrese direccion">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Celular</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="fas fa-phone"></i></span>
                      </div>
                      <input type="text" class="form-control" id="celular" data-inputmask='"mask": "999999999"' data-mask maxlength="9">
                    </div>
                  </div>
                  <div class="form-group clearfix" id="div_sexo" style="display: none">
                    <div> <label for="exampleInputEmail1">Sexo</label></div>
                    <div class="icheck-success d-inline">
                      <input type="radio" name="r_sexo" checked id="sexo_m">
                      <label for="sexo_m">Masculino
                      </label>
                    </div>
                    <div class="icheck-success d-inline">
                      <input type="radio" name="r_sexo" id="sexo_f">
                      <label for="sexo_f">Femenino
                      </label>
                    </div>
                  </div>
                  <div class="form-group" id="div_fn" style="display: none">
                    <label>Fecha nacimiento</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                      </div>
                      <input type="date" id="fecha_nacimiento" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                    </div>
                    <!-- /.input group -->
                  </div>
                </div>
              </form>
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cerrar</button>
        <button type="button" class="btn btn-outline-light" onclick="create()">Guardar</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
