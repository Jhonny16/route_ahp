<html>
<head>
    <?php include_once 'ext_estilos.php'; ?>
</head>
<body class="hold-transition sidebar-mini text-sm">
<div class="wrapper">
    <?php include_once 'est_cabecera.php'; ?>
    <?php include_once 'est_menu.php'; ?>
    <div class="content-wrapper" style="background-color: white">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6" >

                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#"></a></li>
                            <li class="breadcrumb-item active">Mis perfil</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div  class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="card card-default">
                            <div class="card-header">
                                <h3 class="card-title">Mis datos:</h3>
                            </div>
                            <!-- /.card-header -->
                            <!-- form start -->
                            <form role="form">
                                <div class="card-body small">
                                    <input type="text" id="p_empresa_id" style="display: none;">

                                    <div class="form-group clearfix">
                                        <div class="icheck-success d-inline">
                                            <input type="radio" name="p_identidad" checked id="p_ruc">
                                            <label for="p_ruc">RUC
                                            </label>
                                        </div>
                                        <div class="icheck-success d-inline">
                                            <input type="radio" name="p_identidad" id="p_dni">
                                            <label for="p_dni">DNI
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Documento Ruc o DNI</label>
                                        <input type="text" class="form-control" id="p_documento" placeholder="Ingrese RUC o DNI" maxlength="11"
                                        onkeypress="return solonumeros(event);">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Nombre completo o razón social</label>
                                        <input type="text" class="form-control" id="p_nombre" onkeypress="return sololetras(event);"
                                               placeholder="Ingrese nombre completo o razon social">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Dirección</label>
                                        <input type="text" class="form-control" id="p_direccion" placeholder="Ingrese direccion">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputEmail1">Celular</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                            </div>
                                            <input type="text" class="form-control" id="p_celular" data-inputmask='"mask": "999999999"' data-mask maxlength="9">
                                        </div>
                                    </div>
                                    <div class="form-group clearfix" id="div_sexo" style="display: none">
                                        <div> <label for="exampleInputEmail1">Sexo</label></div>
                                        <div class="icheck-success d-inline">
                                            <input type="radio" name="p_rb_sexo" checked id="p_masculino">
                                            <label for="p_masculino">Masculino
                                            </label>
                                        </div>
                                        <div class="icheck-success d-inline">
                                            <input type="radio" name="p_rb_sexo" id="p_femenino">
                                            <label for="p_femenino">Femenino
                                            </label>
                                        </div>
                                    </div>
                                    <div class="form-group" id="div_fn" style="display: none">
                                        <label>Fecha nacimiento</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                            </div>
                                            <input type="date" id="p_nacimiento" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                                        </div>
                                        <!-- /.input group -->
                                    </div>
                                    <div class="form-group clearfix">
                                        <label for="a">Cambiar contraseña</label>
                                        <div class="icheck-primary d-inline">
                                            <input type="radio" id="radioPrimary1" name="r1" >
                                            <label for="radioPrimary1">Si
                                            </label>
                                        </div>
                                        <div class="icheck-primary d-inline">
                                            <input type="radio" id="radioPrimary2" name="r1" checked>
                                            <label for="radioPrimary2">No
                                            </label>
                                        </div>
                                        <input type="password" class="form-control" id="contrasenia" placeholder="Ingrese Contraseña" disabled>

                                    </div>
                                    <div class="form-group text-right">
                                        <input type="checkbox" onclick="myFunction()">Mostrar Password
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <button type="button" class="btn btn-primary" onclick="update_perfil()">Guardar</button>
                                </div>
                            </form>
                        </div>

                    </div>
                    <div  class="col-md-3"></div>

        </section>
        <?php include_once 'modal_vehiculo.php'; ?>

    </div>
    <?php include_once 'est_pie.php'; ?>
</div>

<?php include_once 'ext_scripts.php'; ?>
<script src="../js/login.js"></script>
<script src="../js/validacion.js"></script>
<script src="../js/validate_login.js"></script>
<!--<script src="../js/empresas_list.js"></script>-->
<script src="../js/perfil_empresa.js"></script>

</body>
</html>
