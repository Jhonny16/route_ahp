<div class="modal fade" id="mdl_precio">
    <div class="modal-dialog">
        <div class="modal-content bg-info">
            <div class="modal-header">
                <h4 class="modal-title">Registro</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <form role="form">
                            <div class="card-body">
<!--                                <div class="form-group">-->
<!--                                    <label for="exampleInputEmail1">Colegio</label>-->
<!--                                    <select class="form-control select2bs4" style="width: 100%;"-->
<!--                                            id="combo_colegio_precio">-->
<!--                                    </select>-->
<!--                                </div>-->
                                <div class="form-group">
                                    <label>Colegio</label>
                                    <select class="form-control select2" style="width: 100%;" id="combo_colegio_precio">

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Precio</label>
                                    <input type="number" min="0" max="500" class="form-control" id="precio" maxlength="3"
                                           onkeypress="return solonumeros(event);"
                                           placeholder="Ingrese precio">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Fecha inicial</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                        </div>
                                        <input type="text" id="fecha_incial_precio" class="form-control"
                                               data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd"
                                               data-mask>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Fecha finalización</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                        </div>
                                        <input type="text" id="fecha_final_precio" class="form-control"
                                               data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd"
                                               data-mask>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Descripción</label>
                                    <input type="text" class="form-control" id="descripcion" value="Ninguno"
                                           onkeypress="return sololetras(event);"
                                           placeholder="Ninguno">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-outline-light" data-dismiss="modal" id="close_modal_precio">Cerrar</button>
                <button type="button" class="btn btn-outline-light" onclick="create_price()">Guardar</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
