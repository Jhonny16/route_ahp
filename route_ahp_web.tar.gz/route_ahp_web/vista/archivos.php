<html>
<head>
    <?php include_once 'ext_estilos.php'; ?>
</head>
<body class="hold-transition sidebar-mini text-sm">
<div class="wrapper">
    <?php include_once 'est_cabecera.php'; ?>
    <?php include_once 'est_menu.php'; ?>
    <div class="content-wrapper" style="background-color: white">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">

                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#"></a></li>
                            <li class="breadcrumb-item active">Mis archivos</li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-4">
                        <form role="form" enctype="multipart/form-data" method="post" id="form_licencias">

                            <div class="card card-default ">
                                <div class="card-header">
                                    <h3 class="card-title" id="p_title">Carga de archivos</h3>
                                </div>
                                <div class="card-body">
                                    <input type="text" name="p_proccess" id="p_proccess"
                                           style="display: none;">
                                    <input type="text" name="p_empresa_id" id="p_empresa_id"
                                           style="display: none;">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group" id="divdocs_combo_empresas" style="display: none">
                                                <select class="form-control select2bs4" id="p_combo_empresas"
                                                        name="p_combo_empresas">
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <select class="form-control select2bs4" id="p_combo_licencias"
                                                        name="p_combo_licencias">
                                                </select>


                                            </div>
                                            <div class="form-group" id="divdocs_combo_choferes" style="display: none">
                                                <select class="form-control select2bs4" id="p_combo_choferes"
                                                        name="p_combo_choferes">
                                                </select>
                                            </div>

                                            <div class="form-group" id="divdocs_combo_vehiculos" style="display: none">
                                                <select class="form-control select2bs4" id="p_combo_vehiculos"
                                                        name="p_combo_vehiculos">
                                                </select>
                                            </div>
                                            <hr>
                                            <div class="form-group" id="div_p_imagen" >
                                                <div class="input-group">
                                                    <div class="custom-file">
                                                        <input type="file" class="custom-file-input" id="p_imagen"
                                                               name="p_imagen">
                                                        <label class="custom-file-label" for="p_imagen">Selección de
                                                            archivo(png - jpeg)</label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group" id="div_p_descripcion">
                                                <label for="exampleInputEmail1" style="color: #73797f">Nombre /
                                                    Descripción</label>
                                                <input type="text" class="form-control small" id="p_descripcion"
                                                       name="p_descripcion" onkeypress="return letras_numeros(event);"
                                                       placeholder="Ingrese nombre o descripción para el archivo">
                                            </div>

                                            <div class="form-group" id="div_p_fechas">
                                                <label style="color: #73797f">Fechas (Vigencia)</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                          <span class="input-group-text">
                                                            <i class="far fa-calendar-alt"></i>
                                                          </span>
                                                    </div>
                                                    <input type="text" class="form-control float-right small"
                                                           id="p_fechas_licencias" name="p_fechas_licencias">
                                                </div>
                                            </div>

                                            <div class="form-group clearfix" id="div_p_validacion_licencia" style="display: none">
                                                <input type="text" id="p_validacion" name="p_validacion" style="display: none">
                                                <div><label for="exampleInputEmail1">Validar documento</label></div>
                                                <div class="icheck-success d-inline">
                                                    <input type="radio" name="p_validate"  id="p_sipi">
                                                    <label for="p_sipi">Si
                                                    </label>
                                                </div>
                                                <div class="icheck-success d-inline">
                                                    <input type="radio" name="p_validate" id="p_nopi" checked>
                                                    <label for="p_nopi">No
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="form-group" id="div_p_observacion"  style="display: none">
                                                <label for="exampleInputEmail1" style="color: #73797f">Observación</label>
                                                <input type="text" class="form-control small" id="p_observacion"
                                                       name="p_observacion" onkeypress="return letras_numeros(event);"
                                                       placeholder="Ingrese alguna observación">
                                            </div>

                                        </div>

                                    </div>


                                </div>
                                <div class="card-footer">
                                    <button type="button" class="btn btn-success swalDefaultSuccess" style="display: none" id="toas_success">
                                        Launch Success Toast
                                    </button>
                                    <button type="button" class="btn btn-warning swalDefaultWarning" style="display: none" id="toas_warning">
                                        Launch Warning Toast
                                    </button>
                                    <button type="button" class="btn btn-primary" onclick="save_licence()" title="Guardar archivos">
                                        <i class="fa fa-save"></i> Guardar
                                    </button>
                                    <button type="button" class="btn btn-default" onclick="search_licencias()" title="Búsqueda">
                                        <i class="fa fa-search"></i> Buscar
                                    </button>
                                    <button type="button" class="btn btn-warning" onclick="clear_busqueda()" title="Limpiar todo">
                                        <i class="fa fa-paint-brush"></i> Limpiar
                                    </button>


                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <div class="card card-default small">
                            <div class="card-header">
                                <h3 class="card-title">Resultado de la búsqueda</h3>
                            </div>
                            <div class="card-body" id="tbl_images_licenses">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
    <?php include_once 'est_pie.php'; ?>
</div>

<?php include_once 'ext_scripts.php'; ?>
<script src="../js/login.js"></script>
<script src="../js/validacion.js"></script>
<script src="../js/validate_login.js"></script>
<script src="../js/archivos.js"></script>


</body>
</html>
