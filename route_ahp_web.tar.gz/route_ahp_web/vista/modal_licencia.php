<div class="modal fade" id="mdl_licencia">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" >Licencia de conducir</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <form role="form" id="form_licence" enctype="multipart/form-data" method="post">
                            <input type="text" id="proccess" name="proccess" style="display: none">
                            <input type="text" style="display: none;" id="conductor_id" name="conductor_id" >
                            <input type="text" style="display: none;" id="license_id" name="license_id" >

                            <div class="card-body">
                                <div class="form-group clearfix" id="div_validate_license" style="display: none">
                                    <div><label for="exampleInputEmail1">Validar brevete</label></div>
                                    <div class="icheck-success d-inline">
                                        <input type="radio" name="r_validate" checked id="r_sipi">
                                        <label for="r_sipi">Si
                                        </label>
                                    </div>
                                    <div class="icheck-success d-inline">
                                        <input type="radio" name="r_validate" id="r_nopi">
                                        <label for="r_nopi">No
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group" id="div_image_load_license" style="display:none">

                                </div>

                                <div class="form-group" id="div_image_license">
<!--                                    <label for="exampleInputEmail1">Número</label>-->
                                    <input type="file" name="image" id="image">
                                </div>
                                <div class="form-group" id="div_observacion_license" style="display: none">
                                    <label for="exampleInputEmail1">Observacion</label>
                                    <textarea class="form-control" rows="3" placeholder="Observacion ... "
                                              id="observacion" name="observacion"></textarea>
                                </div>
                                <div class="form-group" id="div_descripcion_license">
                                    <label for="exampleInputEmail1">Descripción</label>
                                    <input type="text" class="form-control" id="name_image" name="name_image"
                                           placeholder="Ingrese descripción" onkeypress="return sololetras(event);">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Fecha revalidación</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                        </div>
                                        <input type="text" id="fecha_revalidacion" name="fecha_revalidacion" class="form-control"
                                               data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd"
                                               data-mask>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" onclick="save_licence()">Guardar</button>

            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
