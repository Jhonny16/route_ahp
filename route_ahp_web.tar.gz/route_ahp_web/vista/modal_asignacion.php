<div class="modal fade" id="mdl_asignacion">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="title_asignacion"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <input type="text" style="display: none" id="cv_id">
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <div class="card-body">
                            <div class="form-group text-sm">
                                <select class="form-control select2bs4" style="width: 100%;"
                                        id="combo_conductor_asign">
                                </select>
                            </div>
                            <div class="form-group text-sm">
                                <select class="form-control select2bs4" style="width: 100%;"
                                        id="combo_vehiculo_asign">
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Fecha inicial</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                    </div>
                                    <input type="text" id="fecha_incial_asignacion" class="form-control"
                                           data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd"
                                           data-mask>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Fecha finalización</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                                    </div>
                                    <input type="text" id="fecha_final_asignacion" class="form-control"
                                           data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd"
                                           data-mask>
                                </div>
                            </div>
                            <div class="form-group clearfix" id="div_baja" style="display: none">
                                <div><label for="exampleInputEmail1">Activo</label></div>
                                <div class="icheck-success d-inline">
                                    <input type="radio" name="r_activo-asignacion" checked id="r_yes">
                                    <label for="r_yes">Si
                                    </label>
                                </div>
                                <div class="icheck-success d-inline">
                                    <input type="radio" name="r_activo-asignacion" id="r_not">
                                    <label for="r_not">No
                                    </label>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                <button type="button" class="btn btn-primary" onclick="create_asignacion()">Aceptar</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
